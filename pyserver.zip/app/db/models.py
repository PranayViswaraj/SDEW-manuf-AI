"""ORM models."""

from datetime import datetime
from enum import StrEnum
from typing import Any

from sqlalchemy import (
    JSON,
    Boolean,
    Float,
    ForeignKey,
    Integer,
    LargeBinary,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import Base
from app.db.types import UTCDateTime, utcnow


class Role(StrEnum):
    ADMIN = "admin"
    ENGINEER = "engineer"
    PROGRAMMER = "programmer"
    OPERATOR = "operator"


class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(primary_key=True)
    username: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    full_name: Mapped[str] = mapped_column(String(128), default="")
    password_hash: Mapped[str] = mapped_column(String(256))
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    # The "allowed to press Start" list (safety rule 4). Set by admin only.
    can_start_machine: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)

    role_links: Mapped[list["UserRole"]] = relationship(
        back_populates="user", cascade="all, delete-orphan", lazy="selectin"
    )

    @property
    def roles(self) -> set[Role]:
        return {Role(link.role) for link in self.role_links}

    def has_role(self, *roles: Role) -> bool:
        return bool(self.roles & set(roles))

    def set_roles(self, roles: set[Role]) -> None:
        keep = [link for link in self.role_links if Role(link.role) in roles]
        existing = {Role(link.role) for link in keep}
        self.role_links = keep + [UserRole(role=r.value) for r in roles - existing]


class UserRole(Base):
    __tablename__ = "user_roles"

    user_id: Mapped[int] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE"), primary_key=True
    )
    role: Mapped[str] = mapped_column(String(32), primary_key=True)

    user: Mapped[User] = relationship(back_populates="role_links")


class AuditLog(Base):
    """Append-only (safety rule 7). Guarded in the app (app/db/guards.py) and by DB triggers.

    No foreign keys on purpose: deleting a user or machine must never touch the log.
    """

    __tablename__ = "audit_log"

    id: Mapped[int] = mapped_column(primary_key=True)
    timestamp: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow, index=True)
    user_id: Mapped[int | None] = mapped_column(Integer, index=True)
    username: Mapped[str | None] = mapped_column(String(64))
    machine_id: Mapped[int | None] = mapped_column(Integer, index=True)
    program_id: Mapped[int | None] = mapped_column(Integer)
    program_hash: Mapped[str | None] = mapped_column(String(64))
    action: Mapped[str] = mapped_column(String(64), index=True)
    payload: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    result: Mapped[str] = mapped_column(String(32))
    error: Mapped[str | None] = mapped_column(Text)


class MachineState(StrEnum):
    """Administrative state set by an admin (live run state comes from the bridge)."""

    IN_SERVICE = "in_service"
    MAINTENANCE = "maintenance"
    RETIRED = "retired"


class ToolType(StrEnum):
    OD_ROUGH = "od_rough"
    OD_FINISH = "od_finish"
    BORE = "bore"
    DRILL = "drill"
    GROOVE = "groove"
    THREAD = "thread"
    STOPPER = "stopper"
    PARTING = "parting"
    OTHER = "other"


# Keys of Machine.limits. All values nullable: TODO(REAL-DATA): from nameplate.
LIMIT_KEYS = (
    "max_turning_diameter",
    "max_turning_length",
    "max_bar_diameter",
    "spindle_rpm_min",
    "spindle_rpm_max",
    "chuck_size",
    "turret_stations",
)


def empty_limits() -> dict[str, Any]:
    return dict.fromkeys(LIMIT_KEYS)


class Machine(Base):
    __tablename__ = "machines"

    id: Mapped[int] = mapped_column(primary_key=True)
    # Stable identifier the bridge config uses for this machine (e.g. "lmw-lathe-1").
    key: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    name: Mapped[str] = mapped_column(String(128))
    make: Mapped[str] = mapped_column(String(64), default="")
    model: Mapped[str] = mapped_column(String(64), default="")
    controller: Mapped[str] = mapped_column(String(64), default="FANUC 0i-TF")
    ip_address: Mapped[str | None] = mapped_column(String(64))
    focas_port: Mapped[int] = mapped_column(Integer, default=8193)
    status: Mapped[str] = mapped_column(String(32), default=MachineState.IN_SERVICE.value)
    bridge_id: Mapped[str | None] = mapped_column(String(64))
    # Safety rule 9: remote start / feed hold / stop OFF unless explicitly enabled.
    remote_control_enabled: Mapped[bool] = mapped_column(Boolean, default=False)
    limits: Mapped[dict[str, Any]] = mapped_column(JSON, default=empty_limits)
    notes: Mapped[str] = mapped_column(Text, default="")
    # Program generator setup last saved for this machine (tools, speeds, feeds), entered by a
    # programmer. Re-offered next time so it is typed only once. Never filled with guesses.
    generator_defaults: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow, onupdate=utcnow)

    tools: Mapped[list["Tool"]] = relationship(
        back_populates="machine",
        cascade="all, delete-orphan",
        order_by="Tool.station",
        lazy="selectin",
    )


class Tool(Base):
    __tablename__ = "tools"
    __table_args__ = (UniqueConstraint("machine_id", "tool_code", name="uq_tool_machine_code"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    machine_id: Mapped[int] = mapped_column(ForeignKey("machines.id", ondelete="CASCADE"))
    station: Mapped[int] = mapped_column(Integer)
    tool_code: Mapped[str] = mapped_column(String(8))  # e.g. "T0101" (tool 01, offset 01)
    description: Mapped[str] = mapped_column(String(128), default="")
    insert_type: Mapped[str] = mapped_column(String(64), default="")
    nose_radius: Mapped[float | None] = mapped_column(Float)
    tool_type: Mapped[str] = mapped_column(String(32))

    machine: Mapped[Machine] = relationship(back_populates="tools")


def grade_key(grade: str) -> str:
    """Normalised grade used to detect duplicates: 'en 8 ' == 'EN8'."""
    return "".join(grade.split()).upper()


class Material(Base):
    __tablename__ = "materials"
    __table_args__ = (UniqueConstraint("grade_key", "bar_diameter", name="uq_material_grade_dia"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    grade: Mapped[str] = mapped_column(String(64))
    grade_key: Mapped[str] = mapped_column(String(64), index=True)
    bar_diameter: Mapped[float] = mapped_column(Float, index=True)  # mm
    available_length: Mapped[float | None] = mapped_column(Float)  # mm per bar
    stock_quantity: Mapped[float | None] = mapped_column(Float)
    quantity_unit: Mapped[str] = mapped_column(String(16), default="bars")
    notes: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow, onupdate=utcnow)


class Bridge(Base):
    """A factory-PC bridge. It authenticates with a token (stored hashed) and verifies command
    signatures with a shared signing key."""

    __tablename__ = "bridges"

    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(64), unique=True, index=True)  # = Machine.bridge_id
    token_hash: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    signing_key: Mapped[str] = mapped_column(String(128))
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)


class ProgramStatus(StrEnum):
    DRAFT = "draft"
    APPROVED = "approved"
    REJECTED = "rejected"
    RETIRED = "retired"


class ProgramSource(StrEnum):
    """Where a program came from. There is deliberately no AI source (safety rule 2)."""

    TRUSTED_IMPORT = "trusted_import"
    UPLOAD = "upload"
    DEMO = "demo"
    GENERATOR = "generator"  # deterministic app.gcode.generator (fixed code, not AI)


class Program(Base):
    """One VERSION of a CNC program for one part on one machine.

    A "family" is (machine_id, part_number, program_number). Changing the text always creates a
    new version (draft); approval belongs to one version and its exact text hash.
    """

    __tablename__ = "programs"
    __table_args__ = (
        UniqueConstraint(
            "machine_id", "part_number", "program_number", "version", name="uq_program_version"
        ),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    machine_id: Mapped[int] = mapped_column(ForeignKey("machines.id", ondelete="RESTRICT"))
    part_number: Mapped[str] = mapped_column(String(64), index=True)
    program_number: Mapped[int] = mapped_column(Integer)
    title: Mapped[str] = mapped_column(String(128), default="")
    version: Mapped[int] = mapped_column(Integer)
    text: Mapped[str] = mapped_column(Text)  # exactly as stored (may contain \r)
    sha256: Mapped[str] = mapped_column(String(64), index=True)
    status: Mapped[str] = mapped_column(String(16), default=ProgramStatus.DRAFT.value)
    source: Mapped[str] = mapped_column(String(32))
    source_note: Mapped[str] = mapped_column(String(256), default="")
    created_by: Mapped[int | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"))
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)
    approved_by: Mapped[int | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"))
    approved_by_name: Mapped[str | None] = mapped_column(String(128))
    approved_at: Mapped[datetime | None] = mapped_column(UTCDateTime)
    approved_hash: Mapped[str | None] = mapped_column(String(64))
    status_note: Mapped[str] = mapped_column(Text, default="")
    proven: Mapped[bool] = mapped_column(Boolean, default=False)
    proven_at: Mapped[datetime | None] = mapped_column(UTCDateTime)
    proven_note: Mapped[str] = mapped_column(String(256), default="")

    machine: Mapped[Machine] = relationship(lazy="joined")


class FeatureTableStatus(StrEnum):
    DRAFT = "draft"
    CONFIRMED = "confirmed"


class FeatureTable(Base):
    """A turned part described as values. Every value has an 'ai' suggestion (may be empty) and
    a 'value' an engineer confirms. See app/services/feature_tables.py for the structure."""

    __tablename__ = "feature_tables"

    id: Mapped[int] = mapped_column(primary_key=True)
    part_number: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    drawing_ref: Mapped[str] = mapped_column(String(128), default="")
    source: Mapped[str] = mapped_column(String(32), default="manual")  # manual | drawing_reader
    data: Mapped[dict[str, Any]] = mapped_column(JSON)
    status: Mapped[str] = mapped_column(String(16), default=FeatureTableStatus.DRAFT.value)
    confirmed_by: Mapped[int | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"))
    confirmed_by_name: Mapped[str | None] = mapped_column(String(128))
    confirmed_at: Mapped[datetime | None] = mapped_column(UTCDateTime)
    confirmed_hash: Mapped[str | None] = mapped_column(String(64))
    created_by: Mapped[int | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"))
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow, onupdate=utcnow)


class RunStatus(StrEnum):
    CHECKLIST = "checklist"  # created, operator working through the checklist
    SEND_FAILED = "send_failed"
    SENT = "sent"  # program on the machine, verified, selected
    RUNNING = "running"
    COMPLETED = "completed"  # machine finished; waiting for the first-piece result
    CLOSED = "closed"  # first-piece result recorded
    ABORTED = "aborted"


ACTIVE_RUN_STATUSES = (
    RunStatus.CHECKLIST.value,
    RunStatus.SEND_FAILED.value,
    RunStatus.SENT.value,
    RunStatus.RUNNING.value,
)


class Run(Base):
    __tablename__ = "runs"

    id: Mapped[int] = mapped_column(primary_key=True)
    machine_id: Mapped[int] = mapped_column(ForeignKey("machines.id", ondelete="RESTRICT"))
    program_id: Mapped[int] = mapped_column(ForeignKey("programs.id", ondelete="RESTRICT"))
    program_hash: Mapped[str] = mapped_column(String(64))
    part_number: Mapped[str] = mapped_column(String(64))
    material_id: Mapped[int | None] = mapped_column(ForeignKey("materials.id", ondelete="SET NULL"))
    material_note: Mapped[str] = mapped_column(String(256), default="")
    status: Mapped[str] = mapped_column(String(16), default=RunStatus.CHECKLIST.value)
    status_note: Mapped[str] = mapped_column(Text, default="")
    checklist: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    operator_id: Mapped[int | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"))
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)
    sent_at: Mapped[datetime | None] = mapped_column(UTCDateTime)
    started_at: Mapped[datetime | None] = mapped_column(UTCDateTime)
    finished_at: Mapped[datetime | None] = mapped_column(UTCDateTime)
    start_mode: Mapped[str | None] = mapped_column(String(16))  # remote | at_machine
    part_count_at_send: Mapped[int | None] = mapped_column(Integer)
    first_piece_result: Mapped[str | None] = mapped_column(String(8))  # pass | fail
    first_piece_measurements: Mapped[list[dict[str, Any]]] = mapped_column(JSON, default=list)
    first_piece_notes: Mapped[str] = mapped_column(Text, default="")
    first_piece_by: Mapped[int | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"))
    first_piece_at: Mapped[datetime | None] = mapped_column(UTCDateTime)

    machine: Mapped[Machine] = relationship(lazy="joined")
    program: Mapped[Program] = relationship(lazy="joined")


class Drawing(Base):
    """A part drawing file as uploaded (PDF or image), kept byte for byte with its SHA-256."""

    __tablename__ = "drawings"

    id: Mapped[int] = mapped_column(primary_key=True)
    part_number: Mapped[str] = mapped_column(String(64), index=True)
    filename: Mapped[str] = mapped_column(String(255))
    content_type: Mapped[str] = mapped_column(String(64))
    size: Mapped[int] = mapped_column(Integer)
    sha256: Mapped[str] = mapped_column(String(64))
    content: Mapped[bytes] = mapped_column(LargeBinary)
    uploaded_by: Mapped[int | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"))
    uploaded_by_name: Mapped[str] = mapped_column(String(128), default="")
    uploaded_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)
