"""Server settings. Everything comes from environment variables / .env (prefix MANUFAI_).

In production (MANUFAI_ENV=production) unsafe settings are refused at start-up, so a
misconfigured server never comes up quietly.
"""

from functools import lru_cache
from typing import Literal

from pydantic import AliasChoices, Field, SecretStr, field_validator, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

DEV_JWT_PREFIX = "dev-only"
DEV_BRIDGE_TOKEN = "dev-bridge-token-not-secret"  # noqa: S105 - published dev value
DEV_BRIDGE_KEY = "dev-bridge-signing-key-not-secret"


class Settings(BaseSettings):
    # .env next to .env.example (project root) or in server/; both are git-ignored. Real
    # environment variables win over either file.
    model_config = SettingsConfigDict(
        env_prefix="MANUFAI_", env_file=("../.env", ".env"), extra="ignore"
    )

    env: Literal["dev", "test", "production"] = "dev"
    database_url: str = "sqlite:///./manufai.db"
    # PostgreSQL connection pool (ignored for SQLite).
    db_pool_size: int = Field(default=10, ge=1, le=100)
    db_max_overflow: int = Field(default=10, ge=0, le=100)
    db_pool_recycle_s: int = Field(default=1800, ge=60)

    jwt_secret: str = Field(
        default=f"{DEV_JWT_PREFIX}-insecure-secret-change-me-in-prod", min_length=32
    )
    jwt_expire_minutes: int = Field(default=480, ge=5, le=24 * 60)
    cors_origins: str = "http://localhost:5173"

    # Login protection: this many wrong passwords in the window locks that user + address.
    login_max_failures: int = Field(default=5, ge=1, le=50)
    login_lockout_s: int = Field(default=300, ge=10, le=24 * 3600)

    # Logging and API docs.
    log_level: Literal["DEBUG", "INFO", "WARNING", "ERROR"] = "INFO"
    log_json: bool = False  # one JSON object per line (for log collectors)
    docs_enabled: bool = True  # /docs and /openapi.json
    # Send Strict-Transport-Security (only when the site is served over HTTPS).
    hsts: bool = False

    # Safety rule 8: UI shows stale/offline after this many seconds without status.
    status_stale_seconds: float = 5.0
    # Bridge rejects commands older than this.
    command_max_age_seconds: float = 10.0
    # Create dev users with published passwords (README). Never in production.
    seed_dev_data: bool = False
    # Seconds to wait for the bridge to send + verify a program.
    bridge_send_timeout_s: float = 60.0
    # DEV ONLY bridge credentials created by the dev seed (match bridge/config.dev.yaml).
    dev_bridge_token: str = DEV_BRIDGE_TOKEN
    dev_bridge_signing_key: str = DEV_BRIDGE_KEY
    # Folder with the trusted O-files imported at seed time (Milestone 9).
    samples_dir: str = "../samples/programs"
    # Sample raw-material CSV loaded by the dev seed (clearly marked SAMPLE DATA).
    sample_materials_csv: str = "../samples/materials/raw-material-register.sample.csv"
    # One-PC install (scripts/start-production.ps1): SQLite is allowed, backed up nightly.
    standalone: bool = False
    # Built web app (web/dist). When set, the server also serves the pages: one port for all.
    web_dir: str | None = None
    # First admin for hosts without a shell (e.g. Render free tier). Created at seed time only
    # when no user with this name exists; the password is never changed afterwards.
    initial_admin_username: str | None = None
    initial_admin_password: str | None = Field(default=None, min_length=10)
    # AI drawing reader (two agents: extractor + verifier). "off" = engineers enter every value.
    # "claude" also needs an Anthropic API key and `pip install .[ai]`.
    ai_reader: Literal["off", "claude"] = "off"
    # Sonnet 5.5 reads Wo-1047 correctly at about a quarter of Opus' cost and 3x faster;
    # "Read again with Opus" is offered on the page for difficult drawings.
    ai_model: str = "claude-sonnet-5-5"
    # "xhigh" with Sonnet: careful reading at a fraction of Opus' price (thinking is most of the
    # bill). "max" ran out of answer room on Wo-1047 (Opus).
    ai_effort: Literal["low", "medium", "high", "xhigh", "max"] = "xhigh"
    # The key: ANTHROPIC_API_KEY from the environment or a .env file (never in git). A secret:
    # it never appears in logs, errors or settings dumps.
    anthropic_api_key: SecretStr | None = Field(
        default=None,
        validation_alias=AliasChoices("ANTHROPIC_API_KEY", "MANUFAI_ANTHROPIC_API_KEY"),
    )

    @field_validator("anthropic_api_key", mode="before")
    @classmethod
    def _blank_key(cls, v: object) -> object:
        return None if isinstance(v, str) and not v.strip() else v

    @field_validator("database_url")
    @classmethod
    def _psycopg_driver(cls, v: str) -> str:
        # Hosting providers hand out postgres:// or postgresql:// URLs; we use psycopg 3.
        for prefix in ("postgres://", "postgresql://"):
            if v.startswith(prefix):
                return "postgresql+psycopg://" + v[len(prefix) :]
        return v

    @model_validator(mode="after")
    def _production_safety(self) -> "Settings":
        if self.env != "production":
            return self
        problems = production_problems(self)
        if problems:
            raise ValueError("Unsafe production settings: " + " ".join(problems))
        return self

    @property
    def cors_origin_list(self) -> list[str]:
        return [o.strip() for o in self.cors_origins.split(",") if o.strip()]

    @property
    def is_production(self) -> bool:
        return self.env == "production"


def production_problems(s: Settings) -> list[str]:
    """Plain-English list of settings that must not be used in production."""
    out = []
    if s.jwt_secret.startswith(DEV_JWT_PREFIX):
        out.append("Set MANUFAI_JWT_SECRET to a long random value.")
    if s.seed_dev_data:
        out.append("Set MANUFAI_SEED_DEV_DATA=false (dev users have published passwords).")
    if "*" in s.cors_origin_list:
        out.append("MANUFAI_CORS_ORIGINS must list your site, not '*'.")
    if s.database_url.startswith("sqlite") and not s.standalone:
        out.append(
            "Use PostgreSQL (MANUFAI_DATABASE_URL), not SQLite, or set MANUFAI_STANDALONE=true "
            "for a single-PC install."
        )
    if s.standalone and s.database_url.startswith("sqlite") and "OneDrive" in s.database_url:
        out.append("Keep the database outside OneDrive: syncing a live database can corrupt it.")
    return out


@lru_cache
def get_settings() -> Settings:
    return Settings()
